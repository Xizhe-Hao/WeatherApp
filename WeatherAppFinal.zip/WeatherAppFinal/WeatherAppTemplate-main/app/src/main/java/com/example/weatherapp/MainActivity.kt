package com.example.weatherapp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.weatherapp.model.Weather.CurrentWeatherResponse
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.Gson
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : AppCompatActivity() {

    // Declare necessary variables
    private val API_KEY = "a02e9788cfefdc6b0417a5aca6691bb3" // Replace with your actual API key
    private val BASE_URL = "https://api.openweathermap.org/data/2.5/weather"
    private val LOCATION_PERMISSION_REQUEST_CODE = 1001
    
    // UI Components
    private lateinit var etCityName: EditText
    private lateinit var btnSearch: Button
    private lateinit var btnRetry: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var weatherContainer: ScrollView
    private lateinit var errorContainer: LinearLayout
    private lateinit var tvErrorMessage: TextView
    private lateinit var tvCityCountry: TextView
    private lateinit var tvUpdatedAt: TextView
    private lateinit var tvWeatherCondition: TextView
    private lateinit var tvTemperature: TextView
    private lateinit var tvMinTemp: TextView
    private lateinit var tvMaxTemp: TextView
    private lateinit var tvSunrise: TextView
    private lateinit var tvSunset: TextView
    private lateinit var tvWind: TextView
    private lateinit var tvPressure: TextView
    private lateinit var tvHumidity: TextView
    
    // Location
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    
    // Weather data
    private var weatherData: CurrentWeatherResponse? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Initialize the view components
        initializeViews()
        
        // Initialize location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Initially hide the weather information and error message views
        weatherContainer.visibility = View.GONE
        errorContainer.visibility = View.GONE

        // Set an OnClickListener on the search button
        btnSearch.setOnClickListener {
            // Retrieve the city name from the EditText
            val cityName = etCityName.text.toString().trim()

            // Dismiss the keyboard so it doesn't cover the UI
            dismissKeyboard()

            // Check if the city name is not empty
            if (cityName.isNotEmpty()) {
                // Show loading indicator
                progressBar.visibility = View.VISIBLE
                weatherContainer.visibility = View.GONE
                errorContainer.visibility = View.GONE
                
                // Build the URL for fetching weather data using the city name
                val urlString = "$BASE_URL?q=$cityName&units=metric&appid=$API_KEY"
                
                // Fetch weather data from the constructed URL in a separate thread
                fetchWeatherData(urlString).start()
            } else {
                // Update the UI to show an error message if no city name is entered
                showError("City name cannot be blank")
            }
        }
        
        // Set OnClickListener for retry button
        btnRetry.setOnClickListener {
            errorContainer.visibility = View.GONE
            
            // Try to get current location or default to Seattle
            getCurrentLocationWeather()
        }
        
        // Load weather for current location or default to Seattle
        getCurrentLocationWeather()
    }
    
    private fun initializeViews() {
        etCityName = findViewById(R.id.etCityName)
        btnSearch = findViewById(R.id.btnSearch)
        btnRetry = findViewById(R.id.btnRetry)
        progressBar = findViewById(R.id.progressBar)
        weatherContainer = findViewById(R.id.weatherContainer)
        errorContainer = findViewById(R.id.errorContainer)
        tvErrorMessage = findViewById(R.id.tvErrorMessage)
        tvCityCountry = findViewById(R.id.tvCityCountry)
        tvUpdatedAt = findViewById(R.id.tvUpdatedAt)
        tvWeatherCondition = findViewById(R.id.tvWeatherCondition)
        tvTemperature = findViewById(R.id.tvTemperature)
        tvMinTemp = findViewById(R.id.tvMinTemp)
        tvMaxTemp = findViewById(R.id.tvMaxTemp)
        tvSunrise = findViewById(R.id.tvSunrise)
        tvSunset = findViewById(R.id.tvSunset)
        tvWind = findViewById(R.id.tvWind)
        tvPressure = findViewById(R.id.tvPressure)
        tvHumidity = findViewById(R.id.tvHumidity)
    }

    private fun dismissKeyboard() {
        val inputMethodManager =
            getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        // Check if no view has focus:
        val currentFocusedView = currentFocus
        currentFocusedView?.let {
            inputMethodManager.hideSoftInputFromWindow(
                it.windowToken,
                InputMethodManager.HIDE_NOT_ALWAYS
            )
        }
    }

    /**
     * Fetches weather data from a specified URL and processes the response.
     *
     * @param urlString The URL string from which the weather data is to be fetched.
     * @return A thread that, when started, performs the network request and data processing.
     */
    fun fetchWeatherData(urlString: String): Thread {
        // Create and return a new Thread object to handle the network operation
        return Thread {
            try {
                // Check network connectivity first
                if (!isNetworkAvailable()) {
                    runOnUiThread {
                        showError("Please connect to internet")
                    }
                    return@Thread
                }
                
                // Create a Gson object for JSON parsing
                val gson = Gson()
                
                // Initialize a URL object from the string URL provided
                val url = URL(urlString)
                
                // Open a URL connection and cast it to HttpURLConnection
                val connection = url.openConnection() as HttpURLConnection
                
                // Check if the response from the connection is successful (HTTP 200 OK)
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    // Logging success message with the retrieved data
                    Log.d("WeatherApp", "Connection successful")
                    
                    // If successful, read the stream from the connection
                    val reader = BufferedReader(InputStreamReader(connection.inputStream))
                    
                    // Read the first line of data
                    val response = reader.readLine()
                    
                    // Close the BufferedReader
                    reader.close()
                    
                    // Parse the JSON response into a CurrentWeatherResponse object using Gson
                    weatherData = gson.fromJson(response, CurrentWeatherResponse::class.java)
                    
                    // Update the UI to reflect the fetched data
                    runOnUiThread {
                        updateWeatherUI()
                    }
                } else {
                    // If connection failed, log the failure and response code
                    Log.e("WeatherApp", "Connection failed with response code: ${connection.responseCode}")
                    
                    // Update the UI to show an error message
                    runOnUiThread {
                        showError("City not found. Please check the spelling.")
                    }
                }
            } catch (e: Exception) {
                // Handle any exceptions that occur during the network operation
                Log.e("WeatherApp", "Error fetching weather data: ${e.message}")
                
                runOnUiThread {
                    showError("Error: ${e.message}")
                }
            }
        }
    }

    /**
     * Updates the UI with weather data.
     */
    private fun updateWeatherUI() {
        weatherData?.let { data ->
            // Hide progress bar and error container
            progressBar.visibility = View.GONE
            errorContainer.visibility = View.GONE
            
            // Show weather container
            weatherContainer.visibility = View.VISIBLE
            
            // Update city and country
            tvCityCountry.text = "${data.name}, ${data.sys.country}"
            
            // Update last updated time
            tvUpdatedAt.text = "Updated at: ${getFormattedDate(data.dt)}"
            
            // Update weather condition
            val weatherCondition = data.weather.firstOrNull()?.main ?: "Unknown"
            tvWeatherCondition.text = weatherCondition
            
            // Update temperature
            tvTemperature.text = "${data.main.temp}°C"
            tvMinTemp.text = "Min Temp: ${data.main.tempMin}°C"
            tvMaxTemp.text = "Max Temp: ${data.main.tempMax}°C"
            
            // Update additional info
            tvSunrise.text = getTimeFromUnix(data.sys.sunrise)
            tvSunset.text = getTimeFromUnix(data.sys.sunset)
            tvWind.text = "${data.wind.speed} m/s"
            tvPressure.text = "${data.main.pressure} hPa"
            tvHumidity.text = "${data.main.humidity}%"
        }
    }

    /**
     * Shows an error message.
     */
    private fun showError(message: String) {
        // Hide progress bar and weather container
        progressBar.visibility = View.GONE
        weatherContainer.visibility = View.GONE
        
        // Show error container and update message
        errorContainer.visibility = View.VISIBLE
        tvErrorMessage.text = message
    }
    
    /**
     * Formats a Unix timestamp into a readable date string.
     */
    private fun getFormattedDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.getDefault())
        val date = Date(timestamp * 1000)
        return sdf.format(date)
    }
    
    /**
     * Formats a Unix timestamp into a readable time string.
     */
    private fun getTimeFromUnix(timestamp: Long): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        sdf.timeZone = TimeZone.getDefault()
        val date = Date(timestamp * 1000)
        return sdf.format(date)
    }
    
    /**
     * Checks if network is available.
     */
    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkCapabilities = connectivityManager.activeNetwork ?: return false
        val activeNetwork = connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
        
        return when {
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
            else -> false
        }
    }
    
    /**
     * Gets weather for current location or defaults to Seattle.
     */
    private fun getCurrentLocationWeather() {
        // Show loading indicator
        progressBar.visibility = View.VISIBLE
        weatherContainer.visibility = View.GONE
        errorContainer.visibility = View.GONE
        
        // Check if we have location permissions
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request permissions if not granted
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            
            // Default to Seattle while waiting for permission
            val seattleUrl = "$BASE_URL?q=Seattle&units=metric&appid=$API_KEY"
            fetchWeatherData(seattleUrl).start()
            return
        }
        
        // Get last known location
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location != null) {
                    // Use location coordinates to get weather
                    val lat = location.latitude
                    val lon = location.longitude
                    val locationUrl = "$BASE_URL?lat=$lat&lon=$lon&units=metric&appid=$API_KEY"
                    fetchWeatherData(locationUrl).start()
                } else {
                    // Default to Seattle if location is null
                    val seattleUrl = "$BASE_URL?q=Seattle&units=metric&appid=$API_KEY"
                    fetchWeatherData(seattleUrl).start()
                }
            }
            .addOnFailureListener {
                // Default to Seattle on failure
                val seattleUrl = "$BASE_URL?q=Seattle&units=metric&appid=$API_KEY"
                fetchWeatherData(seattleUrl).start()
            }
    }
    
    /**
     * Handles permission request results.
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, get current location weather
                getCurrentLocationWeather()
            } else {
                // Permission denied, default to Seattle
                val seattleUrl = "$BASE_URL?q=Seattle&units=metric&appid=$API_KEY"
                fetchWeatherData(seattleUrl).start()
            }
        }
    }
}
